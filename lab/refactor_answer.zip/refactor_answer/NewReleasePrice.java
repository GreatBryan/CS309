

public class NewReleasePrice extends Price {
    public int getPriceCode(){
        return Movie.NEW_RELEASE;
    }

    @Override
    public double getCharge(int daysRented) {
        double result=0;

        result+=daysRented*3;

        return result;
    }

    @Override
    public int getFrequentRenterPoints(int daysRented){
        int frequentRenterPoints = super.getFrequentRenterPoints(0);
        // add bonus for a two day new release rental
        if ( daysRented > super.getFrequentRenterPoints(0))
            frequentRenterPoints++;
        return frequentRenterPoints;
    }

}
