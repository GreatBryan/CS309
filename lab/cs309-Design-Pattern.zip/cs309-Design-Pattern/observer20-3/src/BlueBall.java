import java.awt.*;

public class BlueBall extends Ball implements ObserverBall {
    boolean isUpdated = false;

    public BlueBall(Color color, int xSpeed, int ySpeed, int ballSize) {
        super(color, xSpeed, ySpeed, ballSize);
    }

    public BlueBall(Color color, int xSpeed, int ySpeed, int ballSize, MainPanel subject) {
        super(color, xSpeed, ySpeed, ballSize, subject);
    }

    public BlueBall(Color color, int xSpeed, int ySpeed, int ballSize, MainPanel subject, GreenBall subject2) {
        super(color, xSpeed, ySpeed, ballSize, subject);
        subject2.registerObserver(this);
    }

    @Override
    public void update(char keyChar) {
        super.setXSpeed(-1 * super.getXSpeed());
        super.setYSpeed(-1 * super.getYSpeed());
    }

    @Override
    public void update(int x, int y) {
        int diffX = getX() - x;
        int diffY = getY() - y;
        if (Math.sqrt(diffX * diffX + diffY * diffY) <= 80) {
            setX(diffX > 0 ? getX() + 30 : getX() - 30);
            setY(diffY > 0 ? getY() + 30 : getY() - 30);
            isUpdated = true;
            setColor(new Color(51, 153,255));
        }
    }

    @Override
    public boolean isUpdate() {
        return isUpdated;
    }
}
