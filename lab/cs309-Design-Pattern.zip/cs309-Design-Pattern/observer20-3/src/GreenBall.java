import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class GreenBall extends Ball {
    private MainPanel subject;
    private List<ObserverBall> observers = new LinkedList<>();

    public GreenBall(Color color, int xSpeed, int ySpeed, int ballSize) {
        super(color, xSpeed, ySpeed, ballSize);
    }

    public GreenBall(Color color, int xSpeed, int ySpeed, int ballSize, MainPanel subject) {
        super(color, xSpeed, ySpeed, ballSize, subject);
        this.subject = subject;
    }

    public void registerObserver(ObserverBall observerBall) {
        observers.add(observerBall);
    }

    public synchronized void removeObservers(List<ObserverBall> observerBalls) {
        observers.removeAll(observerBalls);
    }

    public void move() {
        super.move();
        if (subject.isStart())
            notifyObservers();
    }

    public  void notifyObservers() {
        observers.forEach(o -> o.update(super.getX(), super.getY()));
        removeObservers(observers.stream().filter(ObserverBall::isUpdate).collect(Collectors.toList()));
    }


    @Override
    public void update(char keyChar) {
        if (subject.isStart()) {
            switch (keyChar) {
                case 'a':
                    super.setXSpeed(Math.abs(super.getXSpeed()) * -1);
                    break;
                case 'd':
                    super.setXSpeed(Math.abs(super.getXSpeed()));
                    break;
                case 'w':
                    super.setYSpeed(Math.abs(super.getYSpeed()) * -1);
                    break;
                case 's':
                    super.setYSpeed(Math.abs(super.getYSpeed()));
                    break;
            }
        }
    }
}
