public interface ObserverBall {
    public void update(int x, int y);
    public boolean isUpdate();
}
