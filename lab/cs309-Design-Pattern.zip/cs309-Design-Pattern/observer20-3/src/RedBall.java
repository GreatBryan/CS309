import java.awt.*;

public class RedBall extends Ball implements ObserverBall {
    private boolean isUpdated = false;

    public RedBall(Color color, int xSpeed, int ySpeed, int ballSize) {
        super(color, xSpeed, ySpeed, ballSize);
    }

    public RedBall(Color color, int xSpeed, int ySpeed, int ballSize, MainPanel subject) {
        super(color, xSpeed, ySpeed, ballSize, subject);
    }

    public RedBall(Color color, int xSpeed, int ySpeed, int ballSize, MainPanel subject, GreenBall subject2) {
        super(color, xSpeed, ySpeed, ballSize, subject);
        subject2.registerObserver(this);
    }

    @Override
    public void update(char keyChar) {
        if (keyChar == 'a' || keyChar == 'd') {
            int temp = super.getXSpeed();
            super.setXSpeed(super.getYSpeed());
            super.setYSpeed(temp);
        }
    }

    @Override
    public void update(int x, int y) {
        int diffX = getX() - x;
        int diffY = getY() - y;
        if (Math.sqrt(diffX * diffX + diffY * diffY) <= 70) {
            setX(diffX > 0 ? getX() + 40 : getX() - 40);
            setY(diffY > 0 ? getY() + 40 : getY() - 40);
            this.setColor(new Color(255,102,102));
            isUpdated = true;
        }
    }

    @Override
    public boolean isUpdate() {
        return isUpdated;
    }
}
