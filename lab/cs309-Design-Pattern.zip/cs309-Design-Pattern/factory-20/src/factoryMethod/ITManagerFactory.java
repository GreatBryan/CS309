package factoryMethod;

public class ITManagerFactory implements ITStaffFactory{

	@Override
	public ITStaff createITStaff() {
		return new ITManager();
	}

}
