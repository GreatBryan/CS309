package factoryMethod;

public class DeveloperFactory implements ITStaffFactory{

	@Override
	public ITStaff createITStaff() {
		return new Developer();
	}

}
