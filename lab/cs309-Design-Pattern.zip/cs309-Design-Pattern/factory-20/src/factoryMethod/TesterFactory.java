package factoryMethod;

public class TesterFactory implements ITStaffFactory{

	@Override
	public ITStaff createITStaff() {
		return new Tester();
	}

}
