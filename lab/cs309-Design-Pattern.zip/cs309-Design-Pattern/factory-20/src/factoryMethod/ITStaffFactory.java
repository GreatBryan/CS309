package factoryMethod;

public interface ITStaffFactory {
	public ITStaff createITStaff();
}
