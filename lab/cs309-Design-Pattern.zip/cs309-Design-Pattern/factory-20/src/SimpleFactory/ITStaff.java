package SimpleFactory;

public interface ITStaff{
	public String working();
	public int getSalary();
	public String getName();
	public String getUserID();
	public String toString();
}
