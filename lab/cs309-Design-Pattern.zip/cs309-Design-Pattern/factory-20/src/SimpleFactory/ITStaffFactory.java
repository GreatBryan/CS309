package SimpleFactory;

public class ITStaffFactory {
	public ITStaff createITStaff(int i) {
		switch (i) {
		case 1:
			return new ITManager();
		case 2:
			return new Developer();
		case 3:
			return new Tester();
		}
		return null;
	}
}
