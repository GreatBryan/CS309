package abstractFactory.bean;

public class Staff {
    private int id;
    private String username;
    private String password;
    private String department;

    public Staff(){

    }


}
