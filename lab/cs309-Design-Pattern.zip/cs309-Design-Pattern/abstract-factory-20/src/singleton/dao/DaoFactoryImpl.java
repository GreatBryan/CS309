package singleton.dao;

import singleton.util.PropertiesReader;

import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

public class DaoFactoryImpl implements DaoFactory {
    private static DaoFactoryImpl daoFactoryImpl=new DaoFactoryImpl();
    private Properties prop;
    private String prefix;

    private DaoFactoryImpl(){
        // TODO: change the url of properties according to your design
        prop = PropertiesReader.readProperties("abstract-factory-20/src/singleton/resource.properties");
        prefix=prop.getProperty("prefix");
    }

    public static DaoFactoryImpl getInstance(){
        return daoFactoryImpl;
    }


    @Override
    public StaffDao createStaffDao() {
        return (StaffDao)createInstance(StaffDao.class);
    }

    @Override
    public ComputerDao createComputerDao() {
        return (ComputerDao) createInstance(ComputerDao.class);
    }

    private Object createInstance(Class c){
        String className=prop.getProperty(c.getSimpleName());
        try {
            Class clz=Class.forName(prefix+className);
            return clz.getDeclaredConstructor().newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
            e.printStackTrace();
        }
        return null;
    }


}
