import java.awt.*;

public class GreenBall extends Ball {
    private MainPanel subject;

    public GreenBall(Color color, int xSpeed, int ySpeed, int ballSize) {
        super(color, xSpeed, ySpeed, ballSize);
    }

    public GreenBall(Color color, int xSpeed, int ySpeed, int ballSize, MainPanel subject) {
        super(color, xSpeed, ySpeed, ballSize, subject);
        this.subject = subject;
    }


    @Override
    public void update(char keyChar) {
        if (subject.isStart()) {
            switch (keyChar) {
                case 'a':
                    super.setXSpeed(Math.abs(super.getXSpeed()) * -1);
                    break;
                case 'd':
                    super.setXSpeed(Math.abs(super.getXSpeed()));
                    break;
                case 'w':
                    super.setYSpeed(Math.abs(super.getYSpeed()) * -1);
                    break;
                case 's':
                    super.setYSpeed(Math.abs(super.getYSpeed()));
                    break;
            }
        }
    }
}
