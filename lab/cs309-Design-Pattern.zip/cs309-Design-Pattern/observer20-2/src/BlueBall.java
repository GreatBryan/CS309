import java.awt.*;

public class BlueBall extends Ball {
    public BlueBall(Color color, int xSpeed, int ySpeed, int ballSize) {
        super(color, xSpeed, ySpeed, ballSize);
    }

    public BlueBall(Color color, int xSpeed, int ySpeed, int ballSize, MainPanel subject) {
        super(color, xSpeed, ySpeed, ballSize, subject);
    }


    @Override
    public void update(char keyChar) {
        super.setXSpeed(-1 * super.getXSpeed());
        super.setYSpeed(-1 * super.getYSpeed());
    }
}
